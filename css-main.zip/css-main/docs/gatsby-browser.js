// temporary import until primitives moves to core bundle
// importing the index from /css didn't play nice with Gatsby
import '../node_modules/@primer/primitives/tokens-v2-private/css/tokens/base/size/size.css'
import '../node_modules/@primer/primitives/tokens-v2-private/css/tokens/base/typography/typography.css'
import '../node_modules/@primer/primitives/tokens-v2-private/css/tokens/functional/size/border.css'
import '../node_modules/@primer/primitives/tokens-v2-private/css/tokens/functional/size/breakpoints.css'
import '../node_modules/@primer/primitives/tokens-v2-private/css/tokens/functional/size/size-coarse.css'
import '../node_modules/@primer/primitives/tokens-v2-private/css/tokens/functional/size/size-fine.css'
import '../node_modules/@primer/primitives/tokens-v2-private/css/tokens/functional/size/size.css'
import '../node_modules/@primer/primitives/tokens-v2-private/css/tokens/functional/size/viewport.css'
import '../node_modules/@primer/primitives/tokens-v2-private/css/tokens/functional/typography/typography.css'
