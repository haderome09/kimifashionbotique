Preparing for a release.

### Checklist

Make sure these items are checked before merging.

- [ ] Preview the docs change.
- [ ] Preview npm release candidate.
- [ ] CI passes on the release PR.

<!-- diff_report --><!-- /diff_report -->

<!-- bundle_table --><!-- /bundle_table -->
